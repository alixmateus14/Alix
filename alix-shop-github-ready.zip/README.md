
# ALIX SHOP

**ALIX SHOP** este un magazin online pentru bărbați cu produse cool de tip streetwear: tricouri, cămăși, pantaloni, adidași și multe altele.

## Funcționalități
- Coș de cumpărături
- Formulare pentru comandă și retur
- Pagini separate pentru fiecare categorie
- Design responsive
